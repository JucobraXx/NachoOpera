﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SumarNachoOpera;
using RestarNachoOpera;
using MultiplicarNachoOpera;
using DividirNachoOpera;

namespace NachoOpera
{
    public partial class Integracion : Form
    {
        double k = 0;
        double j = 0;
        public Integracion()
        {
            InitializeComponent();
            

        }

        private void cmdSuma_Click(object sender, EventArgs e)
        {
            
             k = Convert.ToDouble(txtNum1.Text);
             j = Convert.ToDouble(txtNum2.Text);

            SumarNacho objSumar = new SumarNacho(k,j);
            double resultado = objSumar.Sumar();
            txtResultado.Text=resultado.ToString();
            
        }

        private void cmdResta_Click(object sender, EventArgs e)
        {
            k = Convert.ToInt64(txtNum1.Text);
            j = Convert.ToInt64(txtNum2.Text);

            RestarNacho objRestar = new RestarNacho(k, j);
            double resultado = objRestar.Restar();
            txtResultado.Text = resultado.ToString();
        }

        private void cmdMultiplicacion_Click(object sender, EventArgs e)
        {
            k = Convert.ToInt64(txtNum1.Text);
            j = Convert.ToInt64(txtNum2.Text);

            MultiplicarNacho objMultiplicar = new MultiplicarNacho(k, j);
            double resultado = objMultiplicar.Multiplicar();
            txtResultado.Text = resultado.ToString();
        }

        private void cmdDivision_Click(object sender, EventArgs e)
        {
            k = Convert.ToInt64(txtNum1.Text);
            j = Convert.ToInt64(txtNum2.Text);

            DivisionNacho objDivision = new DivisionNacho(k, j);
            double resultado = objDivision.Division();
            txtResultado.Text = resultado.ToString();
        }
    }
}
