﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DividirNachoOpera
{
    public class DivisionNacho
    {
        private double a;
        private double b;
        private double r;

        public DivisionNacho(double k, double j)
        {
            a = k;
            b = j;
            r = 0;
        }
        public double R { get { return r; } }

        public double Division()
        {
            r = a / b;
            return r;
        }
    }
}
