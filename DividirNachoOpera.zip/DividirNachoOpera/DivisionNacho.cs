﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DividirNachoOpera
{
    /// <summary>
    /// La clase DivisionNacho realiza la operación de división entre dos números y devuelve el resultado.
    /// </summary>
 
    public class DivisionNacho
    {
        /// <param> name-"a" variable de tipo double, instancia privada </param>
        /// <param> name-"b" variable de tipo double, instancia privada </param>
        /// <param> name-"r" variable de tipo double, instancia privada </param>

        private double a;
        private double b;
        private double r;

        /// <summary>
        /// El constructor inicializa los valores de `a` y `b` con los valores de `k` y `j` respectivamente, y establece `r` en 0.
        /// La propiedad 'public double R' es una propiedad de solo lectura que devuelve el valor de `r`.
        /// </summary>
        /// <param name="k"></param>
        /// <param name="j"></param>
        public DivisionNacho(double k, double j)
        {
            a = k;
            b = j;
            r = 0;
        }
        public double R { get { return r; } }

        /// <return>
        /// El método `Division()` devuelve el valor de la variable `r`, que es el resultado de dividir`a` por `b`.
        /// </return>
        public double Division()
        {
            r = a / b;
            return r;
        }
    }
}
